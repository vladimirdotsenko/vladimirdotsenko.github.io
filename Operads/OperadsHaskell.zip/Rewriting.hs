

module Rewriting where

import Control.Arrow
import Control.Monad
import Data.Maybe
import Data.List

import Utils
import Signature
import OperadTree
import Operations
import Polynomials
import Measure
import CriticalPairs


--------------

-- Rewriting class
--   Signed / unsigned rewriting
--   The basic function takes the following arguments
--
--   rewrite0 <rule> <tree> <context> <scalar>

class (Operations a, CriticalPairs a) => Rewriting a where
  rewrite0 :: Weighting -> Field -> Rewrite a -> a -> (a -> a) -> Scalar -> Maybe (Poly a)

instance Rewriting OT where
  rewrite0 = rewrite0_

instance Rewriting OTS where
  rewrite0 = rewrite0_S

instance Rewriting AT where
  rewrite0 = rewrite0_

instance Rewriting ATS where
  rewrite0 = rewrite0_S

rewrite0_ :: Operations a => Weighting -> Field -> Rewrite a -> a -> (a -> a) -> Scalar -> Maybe (Poly a)
rewrite0_ w z (d,_,poly) t f i = case divide0 t d >>= divide1 of
                                   Just ts -> let g (u,m,j) = let s = f $ graft ts u in (s, measure w s m, mul_ z i j) in Just $ map g poly
                                   Nothing -> Nothing

rewrite0_S :: Signed a => Weighting -> Field -> Rewrite a -> a -> (a -> a) -> Scalar -> Maybe (Poly a)
rewrite0_S w z (d,_,poly) t f i = let ts0 = divide0 t d in
  case ts0 >>= divide1 of
      Just ts -> let b         = divisionSign0 t d + divisionSign1 (fromJust ts0)
                     g (u,m,j) = let v = graft ts u; s = f v in (s, measure w s m, mul_ z i $ mul_ z j $ sign z (b + divisionSign v u))
                 in Just $ map g poly 
      Nothing -> Nothing


---------------

-- Rewrite a monomial

rewriteMono :: Rewriting a => Weighting -> Field -> Rewrite a -> Mono a -> Maybe (Poly a)
rewriteMono w z rw@(d,_,_) (t,_,i) = let f (s,g) = rewrite0 w z rw s g i
                                     in listToMaybe . mapMaybe f $ splitsUpto (depth d) t

-- Rewrite a polynomial

rewritePoly :: Rewriting a => Weighting -> Field -> Rewrite a -> Poly a -> Maybe (Poly a)
rewritePoly w z rw = let f (p,m,q) = liftM ((p++).(++q)) $ rewriteMono w z rw m in listToMaybe . mapMaybe f . foci

-- Apply a list of rewrite rules to a polynomial 

rewrites :: Rewriting a => Weighting -> Field -> [Rewrite a] -> Poly a -> Maybe (Poly a)
rewrites w z rws p = listToMaybe $ mapMaybe (\rw -> rewritePoly w z rw p) rws 

-- Normalise a polynomial by a theory
--   A flag indicates the original was already normal

normalise :: Rewriting a => Weighting -> Field -> [Rewrite a] -> Poly a -> Poly a
normalise w z rws = f where f p = let q = canonical z p in case rewrites w z rws q of Nothing -> q; Just r -> f r

normaliseFlag :: Rewriting a => Weighting -> Field -> [Rewrite a] -> Poly a -> (Bool, Poly a)
normaliseFlag w z rws p = let q = canonical z p in case rewrites w z rws q of Nothing -> (True,q); Just r -> (False, normalise w z rws r)

-- Normalise a rewrite rule by a theory

normaliseRw :: Rewriting a => Weighting -> Field -> [Rewrite a] -> Rewrite a -> Maybe (Rewrite a)
normaliseRw w z rws = snd . normaliseRwFlag w z rws

normaliseRwFlag :: Rewriting a => Weighting -> Field -> [Rewrite a] -> Rewrite a -> (Bool, Maybe (Rewrite a))
normaliseRwFlag w z rws r = case rewrites w z rws (rwToPoly z r) of Nothing -> (True, Just r); Just p -> (False, polyToRw z $ normalise w z rws p)

-- Normalise a set of rewrites w.r.t. itself (plus a theory)
--   Rewrites expected normal w.r.t. theory

normaliseTheory :: Rewriting a => Weighting -> Field -> [Rewrite a] -> [Rewrite a] -> [Rewrite a]
normaliseTheory w z imm mut = f mut [] where
  f []     ys = ys
  f (r:rs) ys = 
    case normaliseRw w z (imm++ys) r of
      Nothing -> f rs ys
      Just s  -> let (xs,zs) = partition (not . fst) $ map (normaliseRwFlag w z [s]) ys
                 in f (mapMaybe id (map snd xs) ++ rs) (s : mapMaybe id (map snd zs)) 



-- Test for indivisibility 

isNormal :: OperadTree a => [Rewrite a] -> Poly a -> Bool
isNormal rs ps = null $ catMaybes [ divide0 s r | (r,_,_) <- rs, (t,_,_) <- ps, (s,_) <- splits t ]



-- The polynomial induced by a critical pair

evaluateCP :: Rewriting a => Weighting -> Field -> CriticalPair a -> Poly a
evaluateCP w z (CP _ t pos r1 r2) = let (s,g) = splitat pos t 
                                    in fromJust (rewrite0 w z r1 t id 1)
                                         ++ map (\(x,y,i) -> (x,y,neg_ z i)) (fromJust $ rewrite0 w z r2 s g 1)
