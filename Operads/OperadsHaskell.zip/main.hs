

module Main where


import IO
import Parsing
import Generation
import PrettyPrinting

main :: IO ()
main = gb "input.txt"

gb :: String -> IO ()
gb input = do
  c <- readIn input
  putStrLn $ show c
  solve c

